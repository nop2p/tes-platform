import { SUBJECT_IDS } from "@/lib";
import { Subject } from "@/types";

export const subjects: Subject[] = [
  {
    id: SUBJECT_IDS.TEACHER_LICENSE,
    code: "001",
    name: "ระเบียบบริหารสถานศึกษา 2569",
    description: "ข้อสอบครูผู้ช่วย",

    examConfig: {
      subjectId: SUBJECT_IDS.TEACHER_LICENSE,
      totalQuestions: 0,
      durationMinutes: 1,
    },

    isActive: true,
  },
  
    {
    id: SUBJECT_IDS.RESEARCH01,
    code: "002",
    name: "วิจัยทางการศึกษา#1",
    description: "ข้อสอบครูผู้ช่วย",

    examConfig: {
      subjectId: SUBJECT_IDS.RESEARCH01,
      totalQuestions: 0,
      durationMinutes: 1,
    },

    isActive: true,
  },
];
