import {
  CHOICE_IDS,
  DIFFICULTY,
  QUESTION_STATUS,
  SUBJECT_IDS,
  TOPIC_IDS,
} from "@/lib";

import { Question } from "@/types";

export const questions: Question[] = [
  {
    id: "q001",
    code: "TES-000001",

    subjectId: SUBJECT_IDS.TEACHER_LICENSE,
    topicId: TOPIC_IDS.ACTIVE_LEARNING,

    order: 1,

    question:
      "ข้อใดอธิบายความหมายของ Active Learning ได้ถูกต้องที่สุด",

    choices: [
      {
        id: CHOICE_IDS.A,
        text: "ผู้เรียนเป็นผู้รับความรู้จากครูเพียงฝ่ายเดียว",
      },
      {
        id: CHOICE_IDS.B,
        text: "ผู้เรียนมีส่วนร่วมในการคิด วิเคราะห์ และลงมือปฏิบัติ",
      },
      {
        id: CHOICE_IDS.C,
        text: "ครูเป็นผู้บรรยายตลอดทั้งคาบ",
      },
      {
        id: CHOICE_IDS.D,
        text: "ผู้เรียนทำแบบฝึกหัดหลังเรียนเท่านั้น",
      },
    ],

    answer: CHOICE_IDS.B,

    explanation: {
      text:
        "Active Learning เน้นให้ผู้เรียนมีส่วนร่วมในการเรียนรู้ผ่านการคิด วิเคราะห์ อภิปราย และลงมือปฏิบัติ",
    },

    difficulty: DIFFICULTY.EASY,

    tags: ["Active Learning"],

    status: QUESTION_STATUS.PUBLISHED,
  },

  {
    id: "q002",
    code: "TES-000002",

    subjectId: SUBJECT_IDS.TEACHER_LICENSE,
    topicId: TOPIC_IDS.PLC,

    order: 2,

    question: "PLC มีวัตถุประสงค์สำคัญที่สุดในข้อใด",

    choices: [
      {
        id: CHOICE_IDS.A,
        text: "เพิ่มชั่วโมงสอน",
      },
      {
        id: CHOICE_IDS.B,
        text: "แลกเปลี่ยนเรียนรู้เพื่อพัฒนาผู้เรียน",
      },
      {
        id: CHOICE_IDS.C,
        text: "ลดจำนวนครู",
      },
      {
        id: CHOICE_IDS.D,
        text: "เพิ่มภาระงานเอกสาร",
      },
    ],

    answer: CHOICE_IDS.B,

    explanation: {
      text:
        "PLC คือชุมชนแห่งการเรียนรู้ทางวิชาชีพ ที่มุ่งพัฒนาคุณภาพผู้เรียนผ่านการทำงานร่วมกันของครู",
    },

    difficulty: DIFFICULTY.EASY,

    tags: ["PLC"],

    status: QUESTION_STATUS.PUBLISHED,
  },

  {
    id: "q003",
    code: "TES-000003",

    subjectId: SUBJECT_IDS.TEACHER_LICENSE,
    topicId: TOPIC_IDS.CURRICULUM,

    order: 3,

    question: "หลักสูตรฐานสมรรถนะมุ่งเน้นสิ่งใด",

    choices: [
      {
        id: CHOICE_IDS.A,
        text: "การท่องจำ",
      },
      {
        id: CHOICE_IDS.B,
        text: "การวัดเฉพาะคะแนนสอบ",
      },
      {
        id: CHOICE_IDS.C,
        text: "สมรรถนะในการปฏิบัติงานจริง",
      },
      {
        id: CHOICE_IDS.D,
        text: "การเรียนตามตำราเพียงอย่างเดียว",
      },
    ],

    answer: CHOICE_IDS.C,

    explanation: {
      text:
        "หลักสูตรฐานสมรรถนะเน้นให้ผู้เรียนสามารถปฏิบัติงานจริงได้ตามสมรรถนะที่กำหนด",
    },

    difficulty: DIFFICULTY.MEDIUM,

    tags: ["Curriculum"],

    status: QUESTION_STATUS.PUBLISHED,
  },

  {
    id: "q004",
    code: "TES-000004",

    subjectId: SUBJECT_IDS.TEACHER_LICENSE,
    topicId: TOPIC_IDS.ACTIVE_LEARNING,

    order: 4,

    question:
      "Bloom's Taxonomy ระดับสูงสุดของ Revised Version คือข้อใด",

    choices: [
      {
        id: CHOICE_IDS.A,
        text: "Remember",
      },
      {
        id: CHOICE_IDS.B,
        text: "Understand",
      },
      {
        id: CHOICE_IDS.C,
        text: "Analyze",
      },
      {
        id: CHOICE_IDS.D,
        text: "Create",
      },
    ],

    answer: CHOICE_IDS.D,

    explanation: {
      text:
        "Bloom's Revised Taxonomy กำหนดระดับสูงสุดคือ Create",
    },

    difficulty: DIFFICULTY.HARD,

    tags: ["Bloom"],

    status: QUESTION_STATUS.PUBLISHED,
  },

  {
    id: "q005",
    code: "TES-000005",

    subjectId: SUBJECT_IDS.TEACHER_LICENSE,
    topicId: TOPIC_IDS.PLC,

    order: 5,

    question: "กิจกรรมใดเป็นตัวอย่างของ PLC",

    choices: [
      {
        id: CHOICE_IDS.A,
        text: "ครูร่วมวิเคราะห์ผลสัมฤทธิ์ของผู้เรียน",
      },
      {
        id: CHOICE_IDS.B,
        text: "ครูทำงานแยกกันตลอดปี",
      },
      {
        id: CHOICE_IDS.C,
        text: "ครูประชุมเฉพาะเรื่องงบประมาณ",
      },
      {
        id: CHOICE_IDS.D,
        text: "ครูสอนโดยไม่สะท้อนผลการสอน",
      },
    ],

    answer: CHOICE_IDS.A,

    explanation: {
      text:
        "PLC เน้นการร่วมกันวิเคราะห์ข้อมูลผู้เรียนและพัฒนาการจัดการเรียนรู้",
    },

    difficulty: DIFFICULTY.MEDIUM,

    tags: ["PLC"],

    status: QUESTION_STATUS.PUBLISHED,
  },
  {
  id: "q006",
  code: "TES-000006",

  subjectId: SUBJECT_IDS.TEACHER_LICENSE,
  topicId: TOPIC_IDS.EDUCATIONAL_PSYCHOLOGY,

  order: 6,

  question:
    'อาจารย์วิศรุตต้องการให้เกิด "การเสริมแรงทางลบ (Negative Reinforcement)" เพื่อให้นักศึกษาแผนกช่างยนต์ส่งรายงานบันทึกการฝึกงานให้ตรงเวลา อาจารย์ควรเลือกใช้สถานการณ์ในข้อใดจึงจะถูกต้องตามหลักจิตวิทยา',

  choices: [
    {
      id: CHOICE_IDS.A,
      text:
        "อาจารย์ประกาศแจกคะแนนพิเศษเพิ่มทันที 5 คะแนน สำหรับนักศึกษาทุกคนที่ส่งเล่มรายงานฝึกงานครบถ้วนก่อนกำหนดเวลา",
    },
    {
      id: CHOICE_IDS.B,
      text:
        "อาจารย์แจ้งว่านักศึกษาคนใดที่ส่งรายงานตรงตามกำหนด จะได้รับการยกเว้นไม่ต้องอยู่ทำความสะอาดโรงฝึกงานในเย็นวันศุกร์",
    },
    {
      id: CHOICE_IDS.C,
      text:
        "อาจารย์ตั้งกฎว่าหากใครส่งรายงานล่าช้ากว่ากำหนด จะต้องถูกหักคะแนนจิตพิสัยวันละ 2 คะแนนจนกว่าจะนำเล่มรายงานมาส่ง",
    },
    {
      id: CHOICE_IDS.D,
      text:
        "อาจารย์สั่งห้ามนักศึกษาที่ยังส่งรายงานไม่ครบ เข้าใช้เครื่องมือทดสอบกำลังเครื่องยนต์ตัวใหม่ที่ทุกคนอยากทดลองใช้งาน",
    },
  ],

  answer: CHOICE_IDS.B,

  explanation: {
    text:
      'การเสริมแรงทางลบ (Negative Reinforcement) คือ การเพิ่มพฤติกรรมเป้าหมาย คือการส่งรายงานตรงเวลา โดยการเอาสิ่งเร้าที่ผู้เรียนไม่พึงปรารถนาออกไป ซึ่งในสถานการณ์นี้คือการยกเว้นไม่ต้องทำความสะอาดโรงฝึกงานเมื่อส่งรายงานตรงเวลา ส่วนข้อ ก. เป็นการเสริมแรงทางบวก ข้อ ค. เป็นการลงโทษทางบวก และข้อ ง. เป็นการลงโทษทางลบ',
  },

  difficulty: DIFFICULTY.MEDIUM,

  tags: [
    "Educational Psychology",
    "Reinforcement",
    "Negative Reinforcement",
  ],

  status: QUESTION_STATUS.PUBLISHED,
},

{
  id: "q007",
  code: "TES-000007",

  subjectId: SUBJECT_IDS.TEACHER_LICENSE,
  topicId: TOPIC_IDS.ACTIVE_LEARNING,

  order: 7,

  question:
    "ข้อใดเป็นบทบาทของครูที่สอดคล้องกับการจัดการเรียนรู้แบบ Active Learning มากที่สุด",

  choices: [
    {
      id: CHOICE_IDS.A,
      text: "เป็นผู้ถ่ายทอดเนื้อหาทั้งหมดให้ผู้เรียนจดจำ",
    },
    {
      id: CHOICE_IDS.B,
      text: "เป็นผู้อำนวยความสะดวกและออกแบบกิจกรรมให้ผู้เรียนเกิดการเรียนรู้",
    },
    {
      id: CHOICE_IDS.C,
      text: "เป็นผู้กำหนดคำตอบที่ผู้เรียนทุกคนต้องตอบเหมือนกัน",
    },
    {
      id: CHOICE_IDS.D,
      text: "เป็นผู้บรรยายเนื้อหาโดยลดกิจกรรมของผู้เรียนให้น้อยที่สุด",
    },
  ],

  answer: CHOICE_IDS.B,

  explanation: {
    text:
      "ในการจัดการเรียนรู้แบบ Active Learning ครูมีบทบาทสำคัญในฐานะผู้ออกแบบการเรียนรู้และผู้อำนวยความสะดวก เพื่อเปิดโอกาสให้ผู้เรียนคิด วิเคราะห์ แลกเปลี่ยนความคิดเห็น และลงมือปฏิบัติด้วยตนเอง",
  },

  difficulty: DIFFICULTY.EASY,

  tags: ["Active Learning", "Teacher Role"],

  status: QUESTION_STATUS.PUBLISHED,
},

{
  id: "q008",
  code: "TES-000008",

  subjectId: SUBJECT_IDS.TEACHER_LICENSE,
  topicId: TOPIC_IDS.PLC,

  order: 8,

  question:
    "หลังจากครูในกลุ่ม PLC ร่วมกันวิเคราะห์ปัญหาการเรียนของผู้เรียนแล้ว ขั้นตอนใดเหมาะสมที่สุดในการนำผลการวิเคราะห์ไปใช้พัฒนาการเรียนรู้",

  choices: [
    {
      id: CHOICE_IDS.A,
      text: "เก็บผลการวิเคราะห์ไว้เป็นข้อมูลโดยไม่ต้องดำเนินการต่อ",
    },
    {
      id: CHOICE_IDS.B,
      text: "ร่วมกันออกแบบแนวทางหรือกิจกรรมเพื่อแก้ปัญหาและนำไปทดลองใช้",
    },
    {
      id: CHOICE_IDS.C,
      text: "ส่งปัญหาทั้งหมดให้ผู้บริหารเป็นผู้แก้ไข",
    },
    {
      id: CHOICE_IDS.D,
      text: "เปลี่ยนผู้เรียนไปอยู่ในห้องเรียนอื่น",
    },
  ],

  answer: CHOICE_IDS.B,

  explanation: {
    text:
      "PLC ไม่ได้สิ้นสุดเพียงการประชุมหรือวิเคราะห์ปัญหา แต่ควรนำข้อมูลที่ได้มาใช้ร่วมกันออกแบบแนวทางพัฒนาการเรียนรู้ ทดลองใช้ สังเกตผล และนำผลกลับมาสะท้อนเพื่อปรับปรุงการจัดการเรียนรู้ต่อไป",
  },

  difficulty: DIFFICULTY.MEDIUM,

  tags: ["PLC", "Problem Solving"],

  status: QUESTION_STATUS.PUBLISHED,
},

{
  id: "q009",
  code: "TES-000009",

  subjectId: SUBJECT_IDS.TEACHER_LICENSE,
  topicId: TOPIC_IDS.CURRICULUM,

  order: 9,

  question:
    "การออกแบบกิจกรรมการเรียนรู้ตามแนวคิดหลักสูตรฐานสมรรถนะควรให้ความสำคัญกับข้อใดมากที่สุด",

  choices: [
    {
      id: CHOICE_IDS.A,
      text: "จำนวนหน้าของเนื้อหาที่ผู้เรียนสามารถอ่านได้",
    },
    {
      id: CHOICE_IDS.B,
      text: "ความสามารถของผู้เรียนในการนำความรู้และทักษะไปใช้ในสถานการณ์จริง",
    },
    {
      id: CHOICE_IDS.C,
      text: "จำนวนข้อสอบปรนัยที่ผู้เรียนทำได้ในหนึ่งชั่วโมง",
    },
    {
      id: CHOICE_IDS.D,
      text: "การจดจำคำจำกัดความในหนังสือเรียนให้ได้มากที่สุด",
    },
  ],

  answer: CHOICE_IDS.B,

  explanation: {
    text:
      "การจัดการเรียนรู้ตามแนวคิดฐานสมรรถนะให้ความสำคัญกับความสามารถในการบูรณาการความรู้ ทักษะ และคุณลักษณะเพื่อนำไปใช้ปฏิบัติหรือแก้ปัญหาในสถานการณ์ที่มีความหมาย ไม่ได้มุ่งเฉพาะการจดจำเนื้อหา",
  },

  difficulty: DIFFICULTY.MEDIUM,

  tags: ["Curriculum", "Competency"],

  status: QUESTION_STATUS.PUBLISHED,
},

{
  id: "q010",
  code: "TES-000010",

  subjectId: SUBJECT_IDS.TEACHER_LICENSE,
  topicId: TOPIC_IDS.EDUCATIONAL_PSYCHOLOGY,

  order: 10,

  question:
    "ครูชมเชยนักเรียนทันทีหลังจากนักเรียนช่วยเก็บอุปกรณ์การเรียนเข้าที่ และพบว่านักเรียนมีพฤติกรรมช่วยเก็บอุปกรณ์บ่อยขึ้น เหตุการณ์นี้สอดคล้องกับหลักการใด",

  choices: [
    {
      id: CHOICE_IDS.A,
      text: "การเสริมแรงทางบวก",
    },
    {
      id: CHOICE_IDS.B,
      text: "การเสริมแรงทางลบ",
    },
    {
      id: CHOICE_IDS.C,
      text: "การลงโทษทางบวก",
    },
    {
      id: CHOICE_IDS.D,
      text: "การลงโทษทางลบ",
    },
  ],

  answer: CHOICE_IDS.A,

  explanation: {
    text:
      "เป็นการเสริมแรงทางบวก เพราะครูเพิ่มสิ่งเร้าที่พึงประสงค์ คือคำชม หลังเกิดพฤติกรรมเป้าหมาย และผลที่ตามมาคือพฤติกรรมช่วยเก็บอุปกรณ์เกิดบ่อยขึ้น",
  },

  difficulty: DIFFICULTY.EASY,

  tags: [
    "Educational Psychology",
    "Reinforcement",
    "Positive Reinforcement",
  ],

  status: QUESTION_STATUS.PUBLISHED,
},
];